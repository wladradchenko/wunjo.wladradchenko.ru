_graphemes = "абвгдеёжзийклмнопрстуфхцчшщъыьэюя"
GRAPHEMES_RU = list(_graphemes)

RU_SET = GRAPHEMES_RU